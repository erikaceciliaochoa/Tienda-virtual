-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-05-2010 a las 16:23:26
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `ochoa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `idcategoria` int(11) NOT NULL auto_increment,
  `descripcion` varchar(25) NOT NULL,
  PRIMARY KEY  (`idcategoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`idcategoria`, `descripcion`) VALUES
(1, 'NARRATIVA'),
(2, 'EMPRESA'),
(3, 'ROMANTICA'),
(4, 'CREC. Y SALUD'),
(5, 'TECNOLOGÍA'),
(6, 'CLÁSICOS'),
(7, 'POLITICA INTERNACIONAL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idproducto` int(11) NOT NULL auto_increment,
  `idcategoria` int(11) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `descripcion` varchar(350) NOT NULL,
  `valor` float NOT NULL,
  PRIMARY KEY  (`idproducto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `productos`
--

INSERT INTO `productos` (`idproducto`, `idcategoria`, `nombre`, `descripcion`, `valor`) VALUES
(1, 1, 'Angeles y demonios', 'Cantidad de Páginas: 599 Peso estimado: 700 gramos. ', 49),
(2, 1, 'El oscuro pasajero', 'Ediciones Umbriel Editores. 256 páginas. ISBN: 8495618834', 50.5),
(3, 1, 'La fortaleza digital', 'La Fortaleza Digital. Publicada originalmente en inglés en 1998.', 49.9),
(4, 1, 'En sus zapatos', 'Cantidad de Páginas: 440 Peso estimado: 580 gramos. ', 39.9),
(5, 4, 'EL FUTURO DEL BUDISMO', 'Formato: Normal. Número de Páginas:96. Encuadernación:  Tapa Blanda.', 60),
(6, 4, 'LA LEY DE MURPHY TIENE EXPLICACION', 'Ediciones Mundo Urano. 240 páginas.', 50),
(7, 3, 'NOBLE DE CORAZON', 'Editorial: Urano Colección. Serie: Herederas americanas ', 60.5),
(8, 2, 'Las 36 estratagemas', 'Fecha de edición: 06/07/2007 Encuadernación: Rustica. Pags: 224', 56.75),
(9, 2, 'Reinventarse profesionalmente', 'Encuadernacion: Rustica. Tamaño: 22x15. Idioma: Castellano. Pags. 256', 57),
(10, 5, 'Only the Paranoid Survive', 'Publisher: HarperCollins Business Published: November 26, 1996. Edicion: Normal pocket', 70),
(11, 5, 'Buscar , de John Battelle', 'Cómo Google y sus rivales han revolucionado los mercados y transformado nuestra cultura.', 95),
(12, 6, 'LA ILIADA', 'Autor: Homero. Prólogo de Alberto Bernabé. Biblioteca EDAF. Págs 495.', 38),
(13, 6, 'LA ODISEA', 'Autor: Homero. Diseño: Alberto Diez. Editorial: Losada. Páginas: 345.', 23),
(14, 6, 'LA TEMPESTAD', 'Autor: William Shakespeare. Diseño: Alberto Diez. Editorial: Losada. Páginas: 240.', 20),
(15, 7, 'Los Estados Desunidos de Latinoamer', 'Autor: Andres Oppenheimer. Páginas:320. Editorial: Edaf.', 65);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL auto_increment,
  `nombre` varchar(15) NOT NULL,
  `clave` varchar(15) NOT NULL,
  PRIMARY KEY  (`idusuario`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nombre`, `clave`) VALUES
(1, 'erika', '4555'),
(2, 'admin', '1234');
